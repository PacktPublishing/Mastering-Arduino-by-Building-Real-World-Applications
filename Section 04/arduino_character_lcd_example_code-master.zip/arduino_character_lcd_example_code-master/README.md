# arduino_character_lcd_example_code
This example codes are tested with 16x2 Character LCD with Arduino Uno
